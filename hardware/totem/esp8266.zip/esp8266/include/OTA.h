#ifndef TOTEM_OTA_H
#define TOTEM_OTA_H

#include <ESP8266WiFi.h>
#include <ArduinoOTA.h>

class OTA {

public:
    static void setup();

    static void check();

};


#endif
