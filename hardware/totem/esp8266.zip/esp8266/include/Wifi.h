#ifndef TOTEM_WIFI_H
#define TOTEM_WIFI_H

#include <ESP8266WiFi.h>
#include "Credentials.h"

class Wifi {
public:
    static void setup();
};


#endif
