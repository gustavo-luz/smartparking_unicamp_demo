#include "OTA.h"

void OTA::setup() {
//    ArduinoOTA.setPort(8266);
//    ArduinoOTA.begin(WiFi.localIP(), "IC2-Parking-Totem", "unicamp123", InternalStorage);
    //TODO: Extra optional configuration could be added
}

void OTA::check() {
//    ArduinoOTA.handle();
}
